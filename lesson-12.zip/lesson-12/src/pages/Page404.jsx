function Page404() {
    return (
        <h1>Page 404</h1>
    );
}

export default Page404;