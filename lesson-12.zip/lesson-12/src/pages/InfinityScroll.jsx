function InfinityScroll() {
    return (
        <section className="infinity-scroll-page">
            <div className="infinity-scroll-page__container">
                <h1 className="infinity-scroll-page__title">Нескінченний скрол</h1>
                <div className="infinity-scroll-page__content">
                    {/* Контент для нескінченного скролу */}
                </div>
            </div>
        </section>
    );
}

export default InfinityScroll;