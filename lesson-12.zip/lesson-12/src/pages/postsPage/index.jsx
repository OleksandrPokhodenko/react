import PostsPage from './PostsPage.jsx';
export default PostsPage;