function PostsForm() {
    return (
        <h1 className="posts-form">Форма створення поста</h1>
    );
}

export default PostsForm;