import PostItem from "./PostItem";

function PostsList({ postsList, handleDelete }) {
    return (
        <div className="posts-list">
            {postsList.map((post) => (
                <PostItem key={post.id} post={post} handleDelete={handleDelete} />
            ))}
        </div>
    );
}

export default PostsList;