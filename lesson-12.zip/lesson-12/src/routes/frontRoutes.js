export default {
    navigate: {
        home: '/',
    }
}