export default {
    navigate: {
        home: '/',
        buses: '/buses',
        hotels: '/hotels',
        summary: '/summary'
    }
}