import { Outlet } from "react-router";
import Footer from "./components/Footer";
import Header from "./components/Header";
import ThemeProvider from "@/providers/ThemeProvider";
import CardListProvider from "@/providers/CardListProvider";

function MainLayout() {
    return (
        <>
            <ThemeProvider>
                <Header />
                <CardListProvider>
                    <main>
                        <Outlet />
                    </main>
                </CardListProvider>
                <Footer />
            </ThemeProvider>
        </>
    );
}

export default MainLayout;