import { CardListContext } from "@/context/CardListContext";
import { buses } from "@/data/busesData";
import { hotels } from "@/data/hotelsData";
import { useState } from "react";

function CardListProvider({ children }) {
    const dataBuses = buses
    const dataHotels = hotels
    const [dataSummary, setDataSummary] = useState([])
    return (
        <CardListContext value={{ dataBuses, dataHotels, dataSummary, setDataSummary }}>
            {children}
        </CardListContext>
    );
}

export default CardListProvider;