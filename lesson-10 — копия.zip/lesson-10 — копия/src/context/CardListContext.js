import { createContext } from "react";

export const CardListContext = createContext()