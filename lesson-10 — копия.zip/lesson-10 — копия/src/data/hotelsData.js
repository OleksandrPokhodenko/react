export const hotels = [
    {
        id: 1,
        name: "Гранд Готель",
        city: "Львів",
        price: 1200,
        rating: 4.5,
        image: "https://vsesanatorii.com/wp-content/uploads/2020/07/s_142620748.jpg",
    },
    {
        id: 2,
        name: "Black Sea Hotel",
        city: "Одеса",
        price: 1800,
        rating: 4.7,
        image: "https://pix10.agoda.net/hotelImages/317/317310/317310_14042023470019137064.jpg?s=1024x768",
    },
    {
        id: 3,
        name: "Premier Palace",
        city: "Київ",
        price: 2500,
        rating: 5.0,
        image: "https://premier-palace-kiev.hotelmix.com.ua/data/Photos/OriginalPhoto/7035/703522/703522480/Premier-Palace-Hotel-Kyiv-Exterior.JPEG",
    },
    {
        id: 4,
        name: "Готель Україна",
        city: "Рівне",
        price: 1100,
        rating: 4.3,
        image: "https://th.bing.com/th/id/R.b3b7c1b2c1156efc327760e694078c1e?rik=A%2fNr0HvoOi1CXg&riu=http%3a%2f%2fhotelukraine.rv.ua%2fwp-content%2fuploads%2f2018%2f07%2f01.jpg&ehk=a6TRjTWfSD%2f%2bPimjRku6aX1jXTHvX%2bvu92kszdBHqns%3d&risl=&pid=ImgRaw&r=0",
    },
];