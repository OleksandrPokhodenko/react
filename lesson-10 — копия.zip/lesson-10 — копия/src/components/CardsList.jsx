import { ThemeContext } from "@/context/ThemeContext";
import { useContext } from "react";
import Card from "./Card";
import { CardListContext } from "@/context/CardListContext";
import { useLocation } from "react-router";

function CardsList() {
    const { dataBuses, dataHotels } = useContext(CardListContext)
    const { theme } = useContext(ThemeContext)
    const { pathname } = useLocation()

    let data
    if (pathname === '/buses') data = dataBuses
    if (pathname === '/hotels') data = dataHotels
    return (
        <div className={theme === 'dark' ? 'card-list card-list--dark-theme' : 'card-list'}>
            <ul className="card-list__list">
                {data.map(item => (
                    <li key={item.id} className="card-list__item">
                        <Card data={item} />
                    </li>
                ))}
            </ul>
        </div>
    );
}

export default CardsList;