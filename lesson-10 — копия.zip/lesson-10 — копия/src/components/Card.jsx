import { useState } from "react";
import { useLocation } from "react-router";

function Card({ data }) {
    const { pathname } = useLocation()
    const [isActive, setIsActive] = useState(false)
    const initButtonTitles = {
        '/hotels': 'Вибрати',
        '/buses': 'Вибрати',
        '/summary': 'Видалити'
    }
    const [buttonTitle, setButtonTitle] = useState(initButtonTitles[pathname])

    const handlerClick = () => {
        if (pathname === '/hotels' || pathname === '/buses') {
            if (!isActive) {
                setButtonTitle('Відмінити')
                setIsActive(true)
            }
            else if (isActive) {
                setButtonTitle('Вибрати')
                setIsActive(false)
            }
        }
    }
    return (
        <div className="card">
            <div className="card__box">
                <img src={data.image} alt="image" className="card__img" />
                <div className="card__info">
                    <div className="card__city">{data.name}</div>
                    {data.rating && data.name && (
                        <>
                            <div className="card__name">{data.city}</div>
                            <div className="card__rating">Рейтинг готеля {data.rating}</div>
                        </>
                    )}
                    <div className="card__price">Ціна: {data.price}грн</div>
                </div>
            </div>
            <button className="card__button" onClick={handlerClick}>{buttonTitle}</button>
        </div>
    );
}

export default Card;